const BACKEND_URL = "https://your-backend.onrender.com"; // Replace with your Render backend URL
export default BACKEND_URL;
